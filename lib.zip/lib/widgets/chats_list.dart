import 'package:flutter/material.dart';

class ChatsList extends StatefulWidget {
  @override
  _ChatsListState createState() => _ChatsListState();
}

class _ChatsListState extends State<ChatsList> {
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(color: Color(0xFFBBFFDD)),
        child: ListView.builder(
            itemCount: chats.length,
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.all(4.0),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(3)),
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SizedBox(
                              width: 50,
                              height: 50,
                              child: DecoratedBox(
                                  decoration: BoxDecoration(
                                      color: const Color(0xFF777777),
                                      borderRadius:
                                          BorderRadius.circular(100)))),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(chats[index].sender.name,
                                textScaleFactor: 1.2,
                                style: const TextStyle(color: Colors.black)),
                            Text(chats[index].text,
                                textScaleFactor: 1,
                                style:
                                    const TextStyle(color: Color(0xFF333333)))
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }));
  }
}

class User {
  final int id;
  final String name;

  User({
    required this.id,
    required this.name,
  });
}

class Message {
  final User sender;
  final String text;

  Message({
    required this.sender,
    required this.text,
  });
}

final User alex = User(id: 1, name: 'Alex');
final User bennet = User(id: 2, name: 'Bennet');
final User chisa = User(id: 3, name: 'Chisa');
final User jonas = User(id: 4, name: 'Jonas');
final User zack = User(id: 5, name: 'Zack');

final users = <User>[alex, bennet, chisa, jonas, zack];

final chats = <Message>[
  Message(sender: chisa, text: 'Check out this cute cat lol'),
  Message(sender: zack, text: 'Wanna go out tonight?'),
  Message(sender: alex, text: 'Hi, im Alex.'),
  Message(sender: bennet, text: 'My house is on fire.'),
  Message(sender: jonas, text: 'Could you send the that file which...'),
  Message(sender: chisa, text: 'Check out this cute cat lol'),
  Message(sender: zack, text: 'Wanna go out tonight?'),
  Message(sender: alex, text: 'Hi, im Alex.'),
  Message(sender: bennet, text: 'My house is on fire.'),
  Message(sender: jonas, text: 'Could you send the that file which...'),
];
