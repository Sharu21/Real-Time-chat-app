import 'package:flutter/material.dart';
import 'package:chatui/widgets/chats_list.dart';

class ChatHome extends StatefulWidget {
  @override
  _ChatHomeState createState() => _ChatHomeState();
}

class _ChatHomeState extends State<ChatHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Chat!'),
          leading: IconButton(
              onPressed: () {}, icon: Icon(Icons.menu), color: Colors.white),
          actions: <Widget>[
            IconButton(onPressed: () {}, icon: Icon(Icons.search))
          ],
        ),
        body: Column(
          children: <Widget>[
            Expanded(
              child: ChatsList(),
            )
          ],
        ));
  }
}
